"use client";

import { useState, useEffect } from "react";
import { 
  Lock, 
  Check, 
  CreditCard, 
  MessageSquare, 
  FileText, 
  Mic, 
  Headphones, 
  ChevronRight,
  ShieldCheck,
  Zap,
  Star
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function IeltsSection() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [step, setStep] = useState(1); // 1: Plans, 2: Payment Instructions, 3: Code Entry

  useEffect(() => {
    const saved = localStorage.getItem("foxeng_premium");
    if (saved === "true") setIsUnlocked(true);
  }, []);

  const handleUnlock = () => {
    if (code.toLowerCase() === "proficiency") {
      setIsUnlocked(true);
      localStorage.setItem("foxeng_premium", "true");
      setShowPaymentModal(false);
    } else {
      setError("Неверный код. Пожалуйста, проверьте и попробуйте снова.");
    }
  };

  if (isUnlocked) {
    return (
      <div className="max-w-6xl mx-auto pb-20">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-4xl font-bold mb-2">IELTS Premium 🎓</h1>
            <p className="text-gray-500">Твоя персонализированная подготовка к IELTS</p>
          </div>
          <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full flex items-center gap-2 font-bold">
            <ShieldCheck className="w-5 h-5" />
            Доступ активен
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Speaking AI Examiner */}
          <div className="bg-white p-8 rounded-3xl border border-border hover:shadow-xl transition-all group cursor-pointer">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
              <Mic className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold mb-3">Speaking AI Examiner</h3>
            <p className="text-gray-500 mb-6">Полноценная имитация экзаменатора. Получи Band Score и детальный анализ ошибок в реальном времени.</p>
            <div className="flex items-center text-primary font-bold">
              Начать практику <ChevronRight className="w-5 h-5 ml-1 transition-transform group-hover:translate-x-1" />
            </div>
          </div>

          {/* Writing AI Checker */}
          <div className="bg-white p-8 rounded-3xl border border-border hover:shadow-xl transition-all group cursor-pointer">
            <div className="w-16 h-16 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center mb-6">
              <FileText className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold mb-3">Writing AI Assistant</h3>
            <p className="text-gray-500 mb-6">Загрузи свое эссе (Task 1 или 2) и получи проверку по официальным критериям IELTS.</p>
            <div className="flex items-center text-primary font-bold">
              Проверить эссе <ChevronRight className="w-5 h-5 ml-1 transition-transform group-hover:translate-x-1" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {["Listening", "Reading", "Vocabulary", "Strategies"].map((item) => (
            <div key={item} className="bg-white p-6 rounded-2xl border border-border hover:border-primary transition-colors cursor-pointer text-center">
              <div className="font-bold">{item}</div>
              <div className="text-sm text-gray-400 mt-1">12 уроков</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto pb-20 text-center">
      <div className="max-w-2xl mx-auto py-20">
        <div className="w-20 h-20 bg-primary/10 text-primary rounded-3xl flex items-center justify-center mx-auto mb-8">
          <Lock className="w-10 h-10" />
        </div>
        <h1 className="text-4xl font-bold mb-4">IELTS Premium Раздел</h1>
        <p className="text-xl text-gray-500 mb-10">
          Подготовься к IELTS с помощью искусственного интеллекта и экспертных материалов.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mb-12">
          <div className="bg-white p-8 rounded-3xl border-2 border-border relative">
            <div className="mb-6">
              <h3 className="text-2xl font-bold">Premium</h3>
              <div className="flex items-baseline gap-1 mt-2">
                <span className="text-3xl font-bold">7 999 ₽</span>
                <span className="text-gray-400 line-through">15 000 ₽</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8">
              {["Теория IELTS", "Практика всех разделов", "AI-проверка Writing"].map((feat) => (
                <li key={feat} className="flex items-center gap-2 text-gray-600">
                  <Check className="w-5 h-5 text-green-500" /> {feat}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => { setStep(1); setShowPaymentModal(true); }}
              className="w-full py-4 bg-secondary text-white rounded-2xl font-bold hover:bg-black transition-colors"
            >
              Выбрать Premium
            </button>
          </div>

          <div className="bg-white p-8 rounded-3xl border-2 border-primary relative shadow-xl shadow-primary/10">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-white px-4 py-1 rounded-full text-sm font-bold uppercase tracking-wider">
              Popular
            </div>
            <div className="mb-6">
              <h3 className="text-2xl font-bold">Premium Plus</h3>
              <div className="flex items-baseline gap-1 mt-2">
                <span className="text-3xl font-bold text-primary">10 000 ₽</span>
                <span className="text-gray-400 line-through">20 000 ₽</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8">
              {[
                "Всё из Premium",
                "Speaking AI Examiner",
                "Персональный AI Tutor",
                "Неограниченные проверки"
              ].map((feat) => (
                <li key={feat} className="flex items-center gap-2 text-gray-600">
                  <Check className="w-5 h-5 text-green-500" /> {feat}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => { setStep(1); setShowPaymentModal(true); }}
              className="w-full py-4 bg-primary text-white rounded-2xl font-bold hover:bg-primary-hover transition-colors shadow-lg shadow-primary/20"
            >
              Выбрать Plus
            </button>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl">
            <div className="p-8">
              {step === 1 && (
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-4">Оплата подписки</h3>
                  <p className="text-gray-500 mb-8">Для активации доступа перейдите по ссылке ниже и совершите оплату.</p>
                  
                  <a 
                    href="https://www.tinkoff.ru/rm/r_SeJVdmBKJd.eqzfxDoCyl/YRWRu93159" 
                    target="_blank"
                    className="flex items-center justify-center gap-3 w-full py-4 bg-primary text-white rounded-2xl font-bold mb-6 hover:bg-primary-hover transition-colors"
                    onClick={() => setStep(2)}
                  >
                    <CreditCard className="w-6 h-6" /> Оплатить в Тинькофф
                  </a>

                  <div className="text-left space-y-3 bg-gray-50 p-4 rounded-2xl text-sm border border-gray-100">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Номер телефона:</span>
                      <span className="font-mono font-bold">+79122302306</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Номер карты:</span>
                      <span className="font-mono font-bold">2200 7009 6619 8169</span>
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <MessageSquare className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">Подтверждение оплаты</h3>
                  <p className="text-gray-600 mb-6">
                    Напишите в Telegram <a href="https://t.me/serezh12" target="_blank" className="text-primary font-bold">@serezh12</a> для подтверждения оплаты и получения кодового слова.
                  </p>
                  <button 
                    onClick={() => setStep(3)}
                    className="w-full py-4 bg-secondary text-white rounded-2xl font-bold"
                  >
                    У меня есть код
                  </button>
                </div>
              )}

              {step === 3 && (
                <div className="text-center">
                  <h3 className="text-xl font-bold mb-4">Введите кодовое слово</h3>
                  <input 
                    type="text" 
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Ваш код (например: proficiency)"
                    className="w-full px-4 py-4 bg-gray-100 rounded-2xl mb-4 text-center text-lg font-bold focus:ring-2 ring-primary outline-none"
                  />
                  {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
                  <button 
                    onClick={handleUnlock}
                    className="w-full py-4 bg-primary text-white rounded-2xl font-bold"
                  >
                    Активировать доступ
                  </button>
                  <button 
                    onClick={() => setStep(1)}
                    className="mt-4 text-gray-400 font-semibold"
                  >
                    Назад
                  </button>
                </div>
              )}
            </div>
            <div className="bg-gray-50 p-4 text-center">
              <button onClick={() => setShowPaymentModal(false)} className="text-sm text-gray-400 hover:text-gray-600">Закрыть</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
