"use client";

import { useState } from "react";
import { 
  PenTool, 
  Sparkles, 
  Clock, 
  History,
  Send,
  CheckCircle2,
  FileText
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function WritingPage() {
  const [text, setText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    // Simulate AI analysis
    setTimeout(() => {
      setResult({
        score: "6.5",
        feedback: "Your essay is well-structured, but you could use more advanced vocabulary to achieve a higher score.",
        corrections: [
          { original: "get better", improved: "enhance" },
          { original: "good", improved: "advantageous" }
        ],
        criteria: {
          "Task Achievement": 7.0,
          "Coherence": 6.5,
          "Lexical Resource": 6.0,
          "Grammar": 6.5
        }
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto pb-20">
      <div className="flex justify-between items-end mb-10">
        <div>
          <h1 className="text-4xl font-bold mb-2">Writing Lab ✍️</h1>
          <p className="text-gray-500 text-lg">Пиши эссе и получай мгновенную проверку от AI.</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-6 py-3 bg-white border border-border rounded-xl font-bold text-gray-600 hover:bg-gray-50 transition-all">
            <History className="w-5 h-5" /> История
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Daily Prompt */}
          <div className="bg-white p-8 rounded-[2rem] border border-border shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <span className="px-4 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold uppercase tracking-wider">Задание дня</span>
              <span className="text-gray-400 text-sm flex items-center gap-1"><Clock className="w-4 h-4" /> 14ч осталось</span>
            </div>
            <h2 className="text-2xl font-bold mb-4">Should governments invest more in space exploration?</h2>
            <p className="text-gray-500 leading-relaxed mb-6">
              Some people believe that space exploration is a waste of resources, while others argue it is essential for the future of humanity. Discuss both views and give your opinion.
            </p>
          </div>

          {/* Editor */}
          <div className="bg-white p-8 rounded-[2rem] border border-border shadow-sm">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Начните писать ваше эссе здесь..."
              className="w-full h-80 text-lg leading-relaxed outline-none resize-none placeholder:text-gray-200"
            />
            <div className="mt-6 flex justify-between items-center border-t pt-6">
              <div className="text-gray-400 font-medium">
                Слов: <span className="text-secondary">{text.trim().split(/\s+/).filter(x => x.length > 0).length}</span>
              </div>
              <button 
                onClick={handleAnalyze}
                disabled={text.length < 50 || isAnalyzing}
                className={cn(
                  "px-8 py-4 rounded-2xl font-bold flex items-center gap-2 transition-all",
                  isAnalyzing ? "bg-gray-100 text-gray-400" : "bg-primary text-white hover:bg-primary-hover shadow-lg shadow-primary/20"
                )}
              >
                {isAnalyzing ? (
                  <>Анализируем...</>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" /> Проверить эссе
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Results / Stats */}
        <div className="space-y-8">
          {result ? (
            <div className="bg-white p-8 rounded-[2rem] border-2 border-primary shadow-xl animate-in fade-in slide-in-from-bottom-4">
              <div className="text-center mb-8">
                <p className="text-gray-400 font-bold uppercase text-xs tracking-widest mb-2">Estimated Band Score</p>
                <div className="text-6xl font-black text-primary">{result.score}</div>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="font-bold mb-4 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500" /> Фидбек
                  </h4>
                  <p className="text-sm text-gray-600 leading-relaxed bg-gray-50 p-4 rounded-xl">
                    {result.feedback}
                  </p>
                </div>

                <div>
                  <h4 className="font-bold mb-4">Критерии</h4>
                  <div className="space-y-3">
                    {Object.entries(result.criteria).map(([key, val]: any) => (
                      <div key={key}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-500">{key}</span>
                          <span className="font-bold">{val}</span>
                        </div>
                        <div className="h-1.5 w-full bg-gray-100 rounded-full">
                          <div className="h-full bg-primary" style={{ width: `${(val / 9) * 100}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-bold mb-4">Улучшения</h4>
                  <div className="space-y-2">
                    {result.corrections.map((c: any, i: number) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <span className="line-through text-red-400">{c.original}</span>
                        <ArrowRight className="w-3 h-3 text-gray-300" />
                        <span className="font-bold text-green-600">{c.improved}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 p-8 rounded-[2rem] border border-dashed border-gray-200 text-center py-20">
              <FileText className="w-12 h-12 text-gray-200 mx-auto mb-4" />
              <p className="text-gray-400 font-medium">Результаты проверки появятся здесь</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ArrowRight(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
  );
}
