"use client";

import { useState, useEffect } from "react";
import { 
  Mic, 
  Square, 
  Play, 
  Volume2, 
  Sparkles, 
  ChevronRight,
  Settings,
  Info
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function SpeakingPage() {
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState(0);
  const [status, setStatus] = useState<"idle" | "listening" | "analyzing" | "result">("idle");

  useEffect(() => {
    let interval: any;
    if (isRecording) {
      interval = setInterval(() => setTimer(t => t + 1), 1000);
    } else {
      setTimer(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const startRecording = () => {
    setIsRecording(true);
    setStatus("listening");
  };

  const stopRecording = () => {
    setIsRecording(false);
    setStatus("analyzing");
    setTimeout(() => setStatus("result"), 3000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="max-w-6xl mx-auto pb-20">
      <div className="mb-10 flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold mb-2">Speaking Lab 🎙️</h1>
          <p className="text-gray-500 text-lg">Практикуй устную речь с AI-экзаменатором FOXeng.</p>
        </div>
        <button className="p-3 bg-white border border-border rounded-xl text-gray-400 hover:text-primary transition-colors">
          <Settings className="w-6 h-6" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[600px]">
        {/* Examiner Column */}
        <div className="lg:col-span-2 bg-white rounded-[2.5rem] border border-border shadow-sm flex flex-col overflow-hidden">
          <div className="p-8 border-b border-gray-50 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white font-bold">FX</div>
              <div>
                <h3 className="font-bold">AI Examiner (Part 1)</h3>
                <p className="text-xs text-green-500 font-bold uppercase tracking-widest flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" /> Online
                </p>
              </div>
            </div>
            <div className="text-sm text-gray-400 flex items-center gap-2">
              <Info className="w-4 h-4" /> IELTS Format
            </div>
          </div>

          <div className="flex-1 p-8 overflow-y-auto space-y-6 bg-gray-50/30">
            {/* Conversation */}
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex-shrink-0 flex items-center justify-center text-primary font-bold text-xs">AI</div>
              <div className="bg-white p-6 rounded-2xl rounded-tl-none border border-border shadow-sm max-w-[80%]">
                <p className="text-gray-700 leading-relaxed">
                  Hello! I'm your examiner for today. Let's start with Part 1. 
                  <br /><br />
                  <b>Can you tell me about your hometown?</b>
                </p>
                <button className="mt-4 flex items-center gap-2 text-primary font-bold text-sm">
                  <Volume2 className="w-4 h-4" /> Listen
                </button>
              </div>
            </div>

            {status === "listening" && (
              <div className="flex gap-4 flex-row-reverse">
                <div className="w-10 h-10 bg-secondary rounded-xl flex-shrink-0 flex items-center justify-center text-white font-bold text-xs">YOU</div>
                <div className="bg-primary text-white p-6 rounded-2xl rounded-tr-none shadow-lg max-w-[80%]">
                  <div className="flex items-center gap-3">
                    <div className="flex gap-1">
                      {[1,2,3,4].map(i => (
                        <div key={i} className="w-1.5 h-4 bg-white/40 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.1}s` }} />
                      ))}
                    </div>
                    <span className="font-bold">Recording... {formatTime(timer)}</span>
                  </div>
                </div>
              </div>
            )}

            {status === "analyzing" && (
              <div className="flex justify-center py-10">
                <div className="flex flex-col items-center gap-4">
                  <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  <p className="text-gray-400 font-bold">AI анализирует твою речь...</p>
                </div>
              </div>
            )}
          </div>

          <div className="p-8 border-t border-gray-50 flex justify-center items-center gap-6">
            {!isRecording && status !== "analyzing" ? (
              <button 
                onClick={startRecording}
                className="w-20 h-20 bg-primary rounded-full flex items-center justify-center text-white shadow-xl shadow-primary/30 hover:scale-105 transition-all"
              >
                <Mic className="w-10 h-10" />
              </button>
            ) : isRecording ? (
              <button 
                onClick={stopRecording}
                className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center text-white shadow-xl shadow-black/20 hover:scale-105 transition-all"
              >
                <Square className="w-8 h-8 fill-white" />
              </button>
            ) : null}
            
            {(status === "idle" || status === "result") && !isRecording && (
              <p className="text-sm font-bold text-gray-400">Нажмите на микрофон, чтобы ответить</p>
            )}
          </div>
        </div>

        {/* Sidebar Info/Stats */}
        <div className="space-y-6">
          <div className={cn(
            "bg-white p-8 rounded-[2rem] border border-border shadow-sm transition-all duration-700",
            status === "result" ? "opacity-100 translate-y-0" : "opacity-40 pointer-events-none"
          )}>
            <div className="text-center mb-8">
              <p className="text-gray-400 font-bold uppercase text-xs tracking-widest mb-2">Fluency Score</p>
              <div className="text-6xl font-black text-primary">7.5</div>
            </div>
            
            <div className="space-y-6">
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="text-sm font-bold mb-2">Совет по произношению:</h4>
                <p className="text-sm text-gray-600">
                  Вы четко произносите согласные, но обратите внимание на интонацию в конце вопросительных предложений.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="text-sm font-bold">Метрики:</h4>
                {[
                  { label: "Pronunciation", val: 8.0 },
                  { label: "Vocabulary", val: 7.0 },
                  { label: "Grammar", val: 7.5 },
                  { label: "Cohesion", val: 7.5 },
                ].map((m) => (
                  <div key={m.label} className="flex justify-between items-center">
                    <span className="text-xs text-gray-500 font-medium">{m.label}</span>
                    <span className="text-xs font-bold text-secondary">{m.val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-secondary text-white p-8 rounded-[2rem]">
            <h3 className="font-bold mb-4">Совет дня</h3>
            <p className="text-sm text-gray-400 leading-relaxed italic">
              "В части 1 старайтесь отвечать в 2-3 предложениях. Не давайте слишком короткие ответы 'Да' или 'Нет'."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
