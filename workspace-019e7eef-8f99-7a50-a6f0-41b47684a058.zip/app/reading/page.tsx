"use client";

import { useState } from "react";
import { 
  FileText, 
  BookOpen, 
  Clock, 
  CheckCircle2, 
  HelpCircle,
  ArrowRight,
  TrendingUp,
  Bookmark
} from "lucide-react";
import { cn } from "@/lib/utils";

const readingTexts = [
  {
    title: "The Impact of Artificial Intelligence on Education",
    level: "C1",
    time: "8 min",
    category: "Academic",
    summary: "An exploration of how AI is reshaping classrooms and the role of teachers in the 21st century."
  },
  {
    title: "Sustainable Urban Development",
    level: "B2",
    time: "10 min",
    category: "Science",
    summary: "Discussing the challenges and solutions for building eco-friendly cities in developing nations."
  },
  {
    title: "The Psychology of Habits",
    level: "B1",
    time: "6 min",
    category: "Life",
    summary: "Simple strategies to build positive habits and break negative ones according to neuroscience."
  }
];

export default function ReadingPage() {
  const [selectedText, setSelectedText] = useState<any>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showFeedback, setShowFeedback] = useState(false);

  return (
    <div className="max-w-6xl mx-auto pb-20">
      <div className="mb-10 flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-bold mb-2">Reading Room 📖</h1>
          <p className="text-gray-500 text-lg">Улучшай навыки чтения и понимания текста.</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-border flex items-center gap-4">
          <div className="text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase">Текстов прочитано</p>
            <p className="text-xl font-bold">42</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase">Accuracy</p>
            <p className="text-xl font-bold text-green-500">88%</p>
          </div>
        </div>
      </div>

      {!selectedText ? (
        <div className="space-y-8">
          <div className="bg-primary/5 border border-primary/20 p-8 rounded-[2.5rem] relative overflow-hidden group">
            <div className="relative z-10 flex items-center justify-between">
              <div className="max-w-xl">
                <span className="bg-primary text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4 inline-block">Статья дня</span>
                <h2 className="text-3xl font-bold mb-4">How Modern Architecture Influences Wellbeing</h2>
                <p className="text-gray-600 mb-6">Исследование о том, как пространство вокруг нас влияет на наше психическое здоровье и продуктивность.</p>
                <button 
                  onClick={() => setSelectedText(readingTexts[0])}
                  className="px-8 py-3 bg-secondary text-white rounded-xl font-bold hover:bg-black transition-all flex items-center gap-2"
                >
                  Читать сейчас <ArrowRight className="w-5 h-5" />
                </button>
              </div>
              <div className="hidden lg:block">
                <FileText className="w-40 h-40 text-primary/10 group-hover:scale-110 transition-transform duration-700" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {readingTexts.map((text, i) => (
              <div 
                key={i} 
                className="bg-white p-8 rounded-[2rem] border border-border hover:border-primary transition-all cursor-pointer group flex flex-col"
                onClick={() => setSelectedText(text)}
              >
                <div className="flex justify-between items-start mb-6">
                  <span className={cn(
                    "px-3 py-1 rounded-lg text-xs font-bold",
                    text.level.startsWith("C") ? "bg-red-50 text-red-600" : "bg-blue-50 text-blue-600"
                  )}>
                    {text.level}
                  </span>
                  <button className="text-gray-300 hover:text-primary"><Bookmark className="w-5 h-5" /></button>
                </div>
                <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">{text.title}</h3>
                <p className="text-sm text-gray-400 mb-6 flex-1">{text.summary}</p>
                <div className="flex items-center gap-4 text-xs font-bold text-gray-400 pt-6 border-t border-gray-50">
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {text.time}</span>
                  <span className="flex items-center gap-1"><BookOpen className="w-4 h-4" /> {text.category}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 space-y-8">
            <button 
              onClick={() => setSelectedText(null)}
              className="text-gray-400 font-bold flex items-center gap-2 hover:text-primary transition-colors"
            >
              <ArrowRight className="w-5 h-5 rotate-180" /> Назад к списку
            </button>
            <div className="bg-white p-12 rounded-[2.5rem] border border-border shadow-sm">
              <h1 className="text-4xl font-bold mb-8">{selectedText.title}</h1>
              <div className="prose prose-lg max-w-none text-gray-700 space-y-6 leading-relaxed">
                <p>
                  Artificial Intelligence (AI) has moved from being a futuristic concept to a ubiquitous reality. In the field of education, its impact is being felt across all levels, from primary schools to higher education institutions. Proponents argue that AI can personalize learning in ways that were previously impossible for a single human teacher...
                </p>
                <p>
                  One of the most significant advantages of AI in the classroom is the ability to provide instant feedback. When a student completes a task, an AI-powered system can immediately identify areas of weakness and suggest targeted exercises to address them. This aligns with the concept of Mastery Learning, where students must master a topic before moving on to the next.
                </p>
                <p>
                  However, critics express concerns regarding the potential loss of human interaction. Education is not merely the transfer of information; it involves mentorship, emotional support, and the development of social skills—areas where AI currently falls short...
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-8">
            <div className="bg-white p-8 rounded-[2.5rem] border border-border shadow-sm sticky top-8">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <HelpCircle className="w-6 h-6 text-primary" /> Тест на понимание
              </h3>
              <div className="space-y-8">
                {[
                  { q: "What is the main advantage of AI mentioned in the text?", options: ["Cost reduction", "Personalized learning", "Replacing teachers"] },
                  { q: "What concept does instant AI feedback align with?", options: ["Active Recall", "Mastery Learning", "Spaced Repetition"] }
                ].map((item, i) => (
                  <div key={i}>
                    <p className="font-bold text-sm mb-4">{i + 1}. {item.q}</p>
                    <div className="space-y-2">
                      {item.options.map((opt) => (
                        <button
                          key={opt}
                          onClick={() => setAnswers({...answers, [i]: opt})}
                          className={cn(
                            "w-full p-4 rounded-xl text-left text-sm font-medium transition-all border",
                            answers[i] === opt ? "bg-primary/10 border-primary text-primary" : "border-gray-100 hover:border-gray-300"
                          )}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <button 
                onClick={() => setShowFeedback(true)}
                className="w-full mt-8 py-4 bg-secondary text-white rounded-2xl font-bold"
              >
                Проверить ответы
              </button>

              {showFeedback && (
                <div className="mt-6 p-4 bg-green-50 rounded-2xl border border-green-100">
                  <p className="text-sm text-green-700 font-bold mb-2">Правильно! 🎉</p>
                  <p className="text-xs text-green-600">
                    AI действительно позволяет персонализировать обучение (Mastery Learning), обеспечивая индивидуальный подход к каждому ученику.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
