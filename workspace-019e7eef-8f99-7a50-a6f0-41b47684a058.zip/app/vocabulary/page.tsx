"use client";

import { useState } from "react";
import { 
  Plus, 
  Search, 
  Play, 
  RotateCcw, 
  Check, 
  X,
  Volume2,
  Trophy,
  Filter
} from "lucide-react";
import { cn } from "@/lib/utils";

const sampleCards = [
  { word: "Resilient", translation: "Стойкий, жизнерадостный", definition: "Able to withstand or recover quickly from difficult conditions." },
  { word: "Ambiguous", translation: "Двусмысленный", definition: "Open to more than one interpretation; not having one obvious meaning." },
  { word: "Pragmatic", translation: "Прагматичный", definition: "Dealing with things sensibly and realistically in a way that is based on practical rather than theoretical considerations." },
  { word: "Mitigate", translation: "Смягчать", definition: "Make (something bad) less severe, serious, or painful." },
  { word: "Eloquent", translation: "Красноречивый", definition: "Fluent or persuasive in speaking or writing." },
];

export default function VocabularyPage() {
  const [view, setView] = useState<"list" | "flashcards" | "test">("list");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [progress, setProgress] = useState(65);

  return (
    <div className="max-w-6xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-6">
        <div>
          <h1 className="text-4xl font-bold mb-2">Vocabulary 📚</h1>
          <div className="flex items-center gap-4 text-gray-500">
            <span className="flex items-center gap-1 font-semibold text-primary"><Trophy className="w-4 h-4" /> 1,240 выучено</span>
            <span>•</span>
            <span>Уровень B2</span>
          </div>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-border">
          <button 
            onClick={() => setView("list")}
            className={cn("px-6 py-2 rounded-xl text-sm font-bold transition-all", view === "list" ? "bg-secondary text-white shadow-lg" : "text-gray-500 hover:bg-gray-50")}
          >
            Список
          </button>
          <button 
            onClick={() => setView("flashcards")}
            className={cn("px-6 py-2 rounded-xl text-sm font-bold transition-all", view === "flashcards" ? "bg-secondary text-white shadow-lg" : "text-gray-500 hover:bg-gray-50")}
          >
            Карточки
          </button>
          <button 
            onClick={() => setView("test")}
            className={cn("px-6 py-2 rounded-xl text-sm font-bold transition-all", view === "test" ? "bg-secondary text-white shadow-lg" : "text-gray-500 hover:bg-gray-50")}
          >
            Тест
          </button>
        </div>
      </div>

      <div className="mb-10 bg-white p-6 rounded-3xl border border-border">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold">Твой прогресс в этом наборе</h2>
          <span className="text-primary font-bold">{progress}%</span>
        </div>
        <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
        </div>
      </div>

      {view === "list" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-3xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-400 hover:border-primary hover:text-primary transition-all cursor-pointer group min-h-[200px]">
            <Plus className="w-10 h-10 mb-2 group-hover:scale-110 transition-transform" />
            <span className="font-bold">Добавить слова</span>
          </div>
          {sampleCards.map((card, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-border hover:shadow-lg transition-all group">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-2xl font-bold">{card.word}</h3>
                <button className="text-gray-300 hover:text-primary"><Volume2 className="w-5 h-5" /></button>
              </div>
              <p className="text-gray-500 mb-4">{card.translation}</p>
              <div className="pt-4 border-t border-gray-50">
                <p className="text-xs text-gray-400 leading-relaxed italic">{card.definition}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {view === "flashcards" && (
        <div className="max-w-2xl mx-auto">
          <div 
            className="perspective-1000 cursor-pointer" 
            onClick={() => setIsFlipped(!isFlipped)}
          >
            <div className={cn(
              "relative h-96 transition-all duration-500 transform-style-3d",
              isFlipped ? "rotate-y-180" : ""
            )}>
              {/* Front */}
              <div className="absolute inset-0 backface-hidden bg-white border-2 border-border rounded-[2rem] flex flex-col items-center justify-center p-12 text-center shadow-xl">
                <span className="text-gray-300 text-sm font-bold uppercase tracking-widest mb-10">Слово</span>
                <h2 className="text-5xl font-bold mb-4">{sampleCards[currentIndex].word}</h2>
                <div className="mt-auto flex items-center gap-2 text-primary font-bold">
                  Нажми, чтобы перевернуть
                </div>
              </div>
              {/* Back */}
              <div className="absolute inset-0 backface-hidden bg-secondary text-white border-2 border-secondary rounded-[2rem] flex flex-col items-center justify-center p-12 text-center shadow-xl rotate-y-180">
                <span className="text-white/30 text-sm font-bold uppercase tracking-widest mb-10">Перевод</span>
                <h2 className="text-4xl font-bold mb-6">{sampleCards[currentIndex].translation}</h2>
                <p className="text-gray-400 text-lg leading-relaxed">{sampleCards[currentIndex].definition}</p>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center mt-12 px-10">
            <button 
              className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center hover:bg-red-500 hover:text-white transition-all shadow-lg shadow-red-100"
              onClick={(e) => { e.stopPropagation(); setCurrentIndex((currentIndex + 1) % sampleCards.length); setIsFlipped(false); }}
            >
              <X className="w-8 h-8" />
            </button>
            <span className="font-bold text-gray-400 text-xl">{currentIndex + 1} / {sampleCards.length}</span>
            <button 
              className="w-16 h-16 bg-green-50 text-green-500 rounded-full flex items-center justify-center hover:bg-green-500 hover:text-white transition-all shadow-lg shadow-green-100"
              onClick={(e) => { e.stopPropagation(); setCurrentIndex((currentIndex + 1) % sampleCards.length); setIsFlipped(false); }}
            >
              <Check className="w-8 h-8" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
