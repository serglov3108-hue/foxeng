"use client";

import { 
  TrendingUp, 
  CheckCircle2, 
  Star, 
  Clock, 
  Zap,
  ChevronRight,
  Book,
  PenTool,
  Mic2,
  FileText
} from "lucide-react";

export default function Dashboard() {
  const levels = ["A1", "A2", "B1", "B2", "C1", "C2"];
  const currentLevel = "B1";

  return (
    <div className="max-w-6xl mx-auto pb-20">
      {/* Header Section */}
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">Привет, Исследователь! 👋</h1>
          <p className="text-gray-500 text-lg">Твой путь к совершенному английскому продолжается.</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-border flex items-center gap-6">
          <div className="text-center">
            <p className="text-xs text-gray-400 uppercase font-bold mb-1">XP Сегодня</p>
            <p className="text-xl font-bold text-primary">450</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="text-center">
            <p className="text-xs text-gray-400 uppercase font-bold mb-1">Слова</p>
            <p className="text-xl font-bold">1,240</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="text-center">
            <p className="text-xs text-gray-400 uppercase font-bold mb-1">Уровень</p>
            <p className="text-xl font-bold text-blue-600">B1</p>
          </div>
        </div>
      </div>

      {/* Learning Path */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-border mb-8">
        <div className="flex justify-between items-center mb-10">
          <h2 className="text-2xl font-bold">Твоя дорожная карта</h2>
          <span className="text-primary font-semibold flex items-center gap-1 cursor-pointer hover:underline">
            Подробный план <ChevronRight className="w-4 h-4" />
          </span>
        </div>
        
        <div className="relative flex justify-between">
          <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-100 -translate-y-1/2 -z-0" />
          <div 
            className="absolute top-1/2 left-0 h-1 bg-primary -translate-y-1/2 transition-all duration-1000" 
            style={{ width: "45%" }} 
          />
          
          {levels.map((level, idx) => (
            <div key={level} className="relative z-10 flex flex-col items-center">
              <div className={`
                w-12 h-12 rounded-full flex items-center justify-center font-bold text-sm border-4 transition-all duration-500
                ${level === currentLevel ? "bg-primary border-orange-200 text-white scale-125 shadow-lg shadow-primary/20" : 
                  idx < levels.indexOf(currentLevel) ? "bg-white border-primary text-primary" : "bg-white border-gray-100 text-gray-300"}
              `}>
                {idx < levels.indexOf(currentLevel) ? <CheckCircle2 className="w-6 h-6" /> : level}
              </div>
              <span className={`mt-3 text-sm font-bold ${level === currentLevel ? "text-primary" : "text-gray-400"}`}>
                {level}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Daily Missions */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-border">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Zap className="w-6 h-6 text-yellow-500 fill-yellow-500" /> Ежедневные миссии
            </h2>
            <div className="space-y-4">
              {[
                { label: "Выучить 10 новых слов", progress: 7, total: 10, icon: Book, color: "bg-blue-50 text-blue-600" },
                { label: "Пройти урок грамматики (Past Simple)", progress: 0, total: 1, icon: FileText, color: "bg-purple-50 text-purple-600" },
                { label: "Записать 1 голосовое сообщение", progress: 1, total: 1, icon: Mic2, color: "bg-green-50 text-green-600" }
              ].map((mission, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-2xl border border-gray-50 hover:border-gray-100 transition-colors">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${mission.color}`}>
                    <mission.icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="font-semibold">{mission.label}</span>
                      <span className="text-sm text-gray-400">{mission.progress}/{mission.total}</span>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${mission.progress === mission.total ? "bg-green-500" : "bg-primary"}`}
                        style={{ width: `${(mission.progress / mission.total) * 100}%` }}
                      />
                    </div>
                  </div>
                  {mission.progress === mission.total && (
                    <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Activity Sections */}
          <div className="grid grid-cols-2 gap-4">
            {[
              { title: "Vocabulary", desc: "1,240 слов выучено", progress: 68, icon: Book, color: "blue" },
              { title: "Grammar", desc: "42/120 тем пройдено", progress: 35, icon: FileText, color: "purple" },
              { title: "Speaking", desc: "B1+ Fluency", progress: 52, icon: Mic2, color: "green" },
              { title: "Writing", desc: "15 эссе написано", progress: 28, icon: PenTool, color: "orange" },
            ].map((section) => (
              <div key={section.title} className="bg-white p-6 rounded-3xl border border-border hover:shadow-md transition-shadow cursor-pointer group">
                <div className="flex justify-between items-start mb-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-${section.color}-50 text-${section.color}-600`}>
                    <section.icon className="w-6 h-6" />
                  </div>
                  <span className="text-sm font-bold text-gray-400 group-hover:text-primary transition-colors">{section.progress}%</span>
                </div>
                <h3 className="text-lg font-bold mb-1">{section.title}</h3>
                <p className="text-sm text-gray-500 mb-4">{section.desc}</p>
                <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${section.progress}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar Stats / Achievements */}
        <div className="space-y-8">
          <div className="bg-secondary text-white p-8 rounded-3xl shadow-lg relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-xl font-bold mb-4">IELTS Premium</h2>
              <p className="text-gray-400 text-sm mb-6">Получи доступ к AI-экзаменатору и персональному плану подготовки.</p>
              <button className="w-full py-3 bg-primary hover:bg-primary-hover text-white rounded-xl font-bold transition-colors">
                Улучшить план
              </button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-primary/20 rounded-full blur-3xl" />
          </div>

          <div className="bg-white p-8 rounded-3xl border border-border">
            <h2 className="text-xl font-bold mb-6">Достижения</h2>
            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className={`aspect-square rounded-2xl flex items-center justify-center border-2 ${i <= 3 ? "border-yellow-200 bg-yellow-50" : "border-gray-50 bg-gray-50 opacity-40"}`}>
                  <Star className={`w-6 h-6 ${i <= 3 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`} />
                </div>
              ))}
            </div>
            <button className="w-full mt-6 text-sm font-bold text-gray-400 hover:text-primary transition-colors">
              Посмотреть все
            </button>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-border">
            <h2 className="text-xl font-bold mb-6">Статистика недели</h2>
            <div className="h-32 flex items-end justify-between gap-2 px-2">
              {[40, 70, 45, 90, 65, 30, 0].map((h, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full bg-gray-100 rounded-t-lg relative group">
                    <div 
                      className="absolute bottom-0 left-0 w-full bg-primary rounded-t-lg transition-all duration-1000 group-hover:bg-primary-hover" 
                      style={{ height: `${h}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-bold text-gray-400">
                    {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"][i]}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
