"use client";

import { useState } from "react";
import { 
  Book, 
  ChevronRight, 
  CheckCircle2, 
  Play, 
  MessageSquare,
  Lock,
  Sparkles,
  ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";

const grammarTopics = {
  "A1": ["To Be", "Present Simple", "Articles", "Plurals"],
  "A2": ["Past Simple", "Present Continuous", "Comparatives", "Prepositions"],
  "B1": ["Present Perfect", "Modal Verbs", "Passive Voice", "Conditionals 1 & 2"],
  "B2": ["Reported Speech", "Gerund vs Infinitive", "Relative Clauses", "Conditionals 3"],
  "C1": ["Inversion", "Mixed Conditionals", "Advanced Modals", "Cleft Sentences"],
  "C2": ["Subjunctive Mood", "Nuanced Cohesion", "Complex Structures"],
};

export default function GrammarPage() {
  const [selectedLevel, setSelectedLevel] = useState("B1");
  const [activeTopic, setActiveTopic] = useState<string | null>(null);

  return (
    <div className="max-w-6xl mx-auto pb-20">
      <div className="mb-10">
        <h1 className="text-4xl font-bold mb-4">Grammar HUB 📖</h1>
        <p className="text-gray-500 text-lg">Абсолютно вся грамматика английского языка от A1 до C2.</p>
      </div>

      {/* Level Selector */}
      <div className="flex flex-wrap gap-3 mb-12 bg-white p-2 rounded-2xl border border-border inline-flex">
        {Object.keys(grammarTopics).map((level) => (
          <button
            key={level}
            onClick={() => setSelectedLevel(level)}
            className={cn(
              "px-8 py-3 rounded-xl font-bold transition-all",
              selectedLevel === level 
                ? "bg-primary text-white shadow-lg shadow-primary/20" 
                : "text-gray-400 hover:bg-gray-50"
            )}
          >
            {level}
          </button>
        ))}
      </div>

      {!activeTopic ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {grammarTopics[selectedLevel as keyof typeof grammarTopics].map((topic, i) => (
            <div 
              key={topic}
              onClick={() => setActiveTopic(topic)}
              className="bg-white p-8 rounded-3xl border border-border hover:border-primary transition-all cursor-pointer group relative overflow-hidden"
            >
              <div className="flex justify-between items-start mb-10">
                <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                  <Book className="w-6 h-6" />
                </div>
                {i === 0 && (
                  <div className="bg-green-100 text-green-600 p-1 rounded-full">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                )}
              </div>
              <h3 className="text-xl font-bold mb-2">{topic}</h3>
              <p className="text-sm text-gray-400">15 уроков • 3 теста • AI Практика</p>
              
              <div className="absolute right-8 bottom-8 text-gray-200 group-hover:text-primary transition-colors transform group-hover:translate-x-2">
                <ArrowRight className="w-8 h-8" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-8">
          <button 
            onClick={() => setActiveTopic(null)}
            className="text-gray-400 font-bold flex items-center gap-2 hover:text-primary transition-colors"
          >
            <ChevronRight className="w-5 h-5 rotate-180" /> Назад к темам
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-10 rounded-[2.5rem] border border-border">
                <h2 className="text-3xl font-bold mb-6">{activeTopic} — Полная теория</h2>
                <div className="prose prose-lg max-w-none text-gray-600 space-y-6">
                  <p>
                    Present Perfect — это время, которое связывает прошлое с настоящим. Мы используем его, когда действие произошло в прошлом, но нам важен результат сейчас или время действия не указано.
                  </p>
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-2xl">
                    <h4 className="font-bold text-blue-900 mb-2">Формула:</h4>
                    <p className="font-mono text-lg">Subject + have/has + Past Participle (V3)</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-8">
                    <div className="p-4 bg-gray-50 rounded-2xl">
                      <p className="font-bold text-gray-900">I have lost my keys.</p>
                      <p className="text-sm">Я потерял ключи (результат: у меня их нет сейчас).</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-2xl">
                      <p className="font-bold text-gray-900">She has visited London.</p>
                      <p className="text-sm">Она посетила Лондон (жизненный опыт).</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-10 rounded-[2.5rem] border border-border">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-bold flex items-center gap-3">
                    <Sparkles className="w-6 h-6 text-primary" /> AI Практика
                  </h2>
                  <span className="bg-primary/10 text-primary px-4 py-1 rounded-full text-xs font-bold">DeepSeek AI</span>
                </div>
                
                <div className="space-y-6">
                  <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                    <p className="font-bold mb-4 italic">Раскрой скобки, используя Present Perfect:</p>
                    <p className="text-xl">1. I _________ (finish) my homework already.</p>
                    <input 
                      type="text" 
                      placeholder="Введите ответ..."
                      className="w-full mt-4 p-4 rounded-xl border border-border focus:ring-2 ring-primary outline-none"
                    />
                  </div>
                  <button className="w-full py-4 bg-secondary text-white rounded-2xl font-bold hover:bg-black transition-all">
                    Проверить ответ
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-secondary text-white p-8 rounded-[2rem]">
                <h3 className="text-xl font-bold mb-6">Прогресс темы</h3>
                <div className="space-y-4">
                  {[
                    "Основные правила",
                    "Слова-маркеры",
                    "Отрицание и вопросы",
                    "Разница с Past Simple",
                    "Финальный тест"
                  ].map((step, i) => (
                    <div key={step} className="flex items-center gap-3">
                      <div className={cn(
                        "w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold",
                        i === 0 ? "bg-primary" : "bg-white/10"
                      )}>
                        {i === 0 ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
                      </div>
                      <span className={i === 0 ? "font-bold" : "text-gray-400"}>{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
