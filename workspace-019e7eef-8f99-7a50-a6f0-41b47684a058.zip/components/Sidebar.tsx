"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  Home, 
  BookOpen, 
  PenTool, 
  Mic2, 
  FileText, 
  GraduationCap, 
  Settings, 
  Award,
  Wallet,
  Trophy
} from "lucide-react";
import { cn } from "@/lib/utils";

const menuItems = [
  { icon: Home, label: "Главная", href: "/" },
  { icon: BookOpen, label: "Vocabulary", href: "/vocabulary" },
  { icon: FileText, label: "Grammar", href: "/grammar" },
  { icon: PenTool, label: "Writing", href: "/writing" },
  { icon: Mic2, label: "Speaking", href: "/speaking" },
  { icon: FileText, label: "Reading", href: "/reading" },
  { icon: GraduationCap, label: "IELTS Premium", href: "/ielts", premium: true },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-secondary text-white p-6 flex flex-col z-50">
      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
          <span className="font-bold text-xl">F</span>
        </div>
        <span className="text-2xl font-bold tracking-tight">FOXeng</span>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
              pathname === item.href 
                ? "bg-primary text-white" 
                : "text-gray-400 hover:bg-white/5 hover:text-white"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5",
              item.premium && pathname !== item.href ? "text-primary" : ""
            )} />
            <span className="font-medium">{item.label}</span>
            {item.premium && (
              <div className="ml-auto">
                <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              </div>
            )}
          </Link>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-white/10 space-y-4">
        <div className="flex items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold">1,250 FX</span>
          </div>
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-yellow-500" />
            <span className="text-sm font-semibold">7 Дней</span>
          </div>
        </div>
        
        <div className="bg-white/5 rounded-2xl p-4">
          <div className="flex justify-between text-xs mb-2">
            <span className="text-gray-400">Прогресс до B2</span>
            <span className="text-primary">65%</span>
          </div>
          <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-primary" style={{ width: "65%" }} />
          </div>
        </div>
      </div>
    </aside>
  );
}
